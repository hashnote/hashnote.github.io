<?php
/* ----------------------------------------------------
* Template Name: DT - jwplayer
* @author: Doothemes
* @author URI: https://doothemes.com/
* @copyright: (c) 2018 Doothemes. All rights reserved
* ----------------------------------------------------
*
* @since 2.1.5
*
*/

// Libraries and dynamic data
$google = new DooGdrive;
$source = urldecode(doo_isset($_GET,'source'));
$typeso = doo_isset($_GET,'type');
$postid = doo_isset($_GET,'id');
$images = get_post_meta($postid,'imagenes', true);
$jwpkey = get_option('dt_jw_key','IMtAJf5X9E17C1gol8B45QJL5vWOCxYUDyznpA==');
$jwplal = get_option('dt_jw_librarie','https://content.jwplatform.com/libraries/oqxCz8Dy.js');

// Compose data for Json
$data = array(
    'file'  => ($typeso == 'gdrive') ? $google->get_data(doo_define_gdrive($source)) : $source,
    'image' => esc_url(rand_images($images, 'original', true, true)),
    'link'  => esc_url(home_url()),
    'text'  => get_option('dt_jw_abouttext','DooPlay Theme WordPress'),
    'color' => get_option('dt_jw_skinactive','#0b7ef4'),
    'logo'  => get_option('dt_jw_logo'),
    'lposi' => get_option('dt_jw_logo_position','top-right'),
    'auto'  => get_option('dt_vplayer_autoplay_jwplayer','false'),
    'flash' =>  DOO_URI.'/assets/jwplayer/jwplayer.flash.swf'
);

// Render JW Player
require_once( DOO_DIR.'/pages/sections/'.DOO_THEME_JWPLAYER.'.php');
