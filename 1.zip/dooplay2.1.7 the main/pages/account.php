<?php
/*
Template Name: DT - Account page
*/

$option = get_option('dt_register_user');

if( DOO_THEME_USER_MOD == true && $option == 'true' ) {

    if (is_user_logged_in()):
    	// pagina de mi cuenta
    	get_template_part('pages/sections/account');
    else:
    	get_template_part('pages/sections/dt_head');
    	if( isset( $_GET['action'] ) and $_GET['action'] =='sign-in'):
    		get_template_part('pages/sections/register');
    	else:
    		get_template_part('pages/sections/login');
    	endif;
    	get_template_part('pages/sections/dt_foot');
    endif;

} else {

    _d('Module disabled');

}
