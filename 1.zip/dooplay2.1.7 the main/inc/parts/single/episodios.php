<?php
/*
* -------------------------------------------------------------------------------------
* @author: Doothemes
* @author URI: https://doothemes.com/
* @aopyright: (c) 2018 Doothemes. All rights reserved
* -------------------------------------------------------------------------------------
*
* @since 2.1.5
*
*/

// All Postmeta
$postmeta = doo_postmeta_episodes($post->ID);
$player   = get_post_meta($post->ID, 'repeatable_fields', true);
$pviews   = get_post_meta($post->ID, 'dt_views_count', true);
$tviews   = ($pviews) ? sprintf( __d('%s Views'), $pviews) : __d('0 Views');
$episode  = doo_isset($postmeta,'episodio');
$images   = doo_isset($postmeta, 'imagenes');
// Options
$player_ads = get_option('dt_vplayer_ads');
$player_wht = get_option('dt_vplayer_width','regular');

// End PHP
?>
<style>#seasons .se-c .se-a ul.episodios li.mark-<?php echo $episode; ?> {opacity: 0.2;}</style>

<?php if($player_wht == 'bigger') { ?>
    <!-- Bigger Player view -->
    <div class="dooplay_player">
        <div id="playcontainer" class="play bigger">
            <?php if($player_ads) echo "<div class='asgdc'>".stripslashes($player_ads)."</div>"; ?>
            <div id="dooplay_player_response"></div>
        </div>
    </div>
<?php } ?>


<!-- Start Single -->
<div id="single" class="dtsingle">


    <!-- Edit link response Ajax -->
    <div id="edit_link"></div>


    <!-- Start Post -->
    <?php if(have_posts()) :while (have_posts()) : the_post(); doo_set_views($post->ID); ?>
	<div class="content">


        <!-- Episode Player Options -->
        <?php if($player){ ?>
        <div class="dooplay_player">
            <?php if($player_wht == 'regular'){ ?>
            <div id="playcontainer" class="play">
                <?php if($player_ads) echo "<div class='asgdc'>".stripslashes($player_ads)."</div>"; ?>
                <div id="dooplay_player_response"></div>
            </div>
            <?php } ?>
            <h2><?php _d('Video Sources'); ?> <span id="playernotice" data-text="<?php echo $tviews; ?>"><?php echo $tviews; ?></span></h2>
            <div id="playeroptions" class="<?php echo (!wp_is_mobile()) ? 'options scrolling' : 'options'; ?>">
                <ul>
                    <?php $num = 1; foreach($player as $play){ ?>
                    <li id="player-option-<?=$num;?>" class="dooplay_player_option <?php if($num == 1) echo 'jump on'; ?>" data-post="<?=$post->ID;?>" data-nume="<?=$num;?>">
                        <i class="icon-play3"></i>
                        <span class="title"><?=$play['name'];?></span>
                        <span class="server"><?php echo get_servername($play['url'], $play['select']);?></span>
                        <?php if(doo_isset($play,'idioma')) { echo "<span class='flag'><img src='".DOO_URI."/assets/img/flags/{$play['idioma']}.png'></span>"; } ?>
                        <span class="loader"></span>
                    </li>
                    <?php $num++; } ?>
                </ul>
            </div>
        </div>
        <?php } ?>


        <!-- Episodes paginator -->
		<?php get_template_part('inc/parts/single/listas/pag_episodes'); ?>

        <!-- Episode Info -->
		<div id="info" class="sbox">
			<h1 class="epih1"><?php echo doo_isset($postmeta,'serie'); ?> <?php echo doo_isset($postmeta,'temporada'); ?>x<?php echo doo_isset($postmeta,'episodio'); ?></h1>
			<div itemprop="description" class="wp-content">
				<h3 class="epih3"><?php echo doo_isset($postmeta,'episode_name'); ?></h3>
				<?php the_content(); ?>
				<?php if($images) { ?>
				<div id="dt_galery" class="galeria animation-2">
					<?php dt_get_images("w300",$images); ?>
				</div>
				<?php } ?>
			</div>
			<?php if($d = doo_isset($postmeta, 'air_date')) { echo '<span class="date">'. doo_date_compose($d).'</span>'; } ?>
		</div>


        <!-- Episode Social Links -->
		<?php links_social_single($post->ID); ?>


        <!-- Episode Ads -->
        <?php if( get_option('ads_ss_4') =="true") { if($ads = get_option('ads_spot_single')) { echo '<div class="sbox"><div class="module_single_ads">'. stripslashes($ads). '</div></div>'; } } ?>


        <!-- Episode Links -->
		<?php if(DOO_THEME_DOWNLOAD_MOD) get_template_part('inc/parts/single/listas/links'); ?>


        <!-- Season Episodes List -->
		<div class="sbox">
			<h2><?php echo doo_isset($postmeta,'serie'); ?> <?php _d('season'); ?> <?php echo doo_isset($postmeta,'temporada'); ?></h2>
			<?php get_template_part('inc/parts/single/listas/se'); ?>
		</div>


        <!-- Episode comments -->
		<?php get_template_part('inc/parts/comments'); ?>


	</div>
    <!-- End Post-->
	<?php endwhile; endif; ?>


    <!-- Episode Sidebar -->
    <div class="sidebar scrolling">
		<?php dynamic_sidebar('sidebar-tvshows'); ?>
	</div>
    <!-- End Sidebar -->


</div>
<!-- End Single -->
