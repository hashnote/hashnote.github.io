<?php
/*
* -------------------------------------------------------------------------------------
* @author: Doothemes
* @author URI: https://doothemes.com/
* @aopyright: (c) 2018 Doothemes. All rights reserved
* -------------------------------------------------------------------------------------
*
* @since 2.1.7
*
*/

// All Postmeta
$postmeta = doo_postmeta_movies($post->ID);
// Movies Meta data
$trailer = doo_isset($postmeta,'youtube_id');
$player  = get_post_meta($post->ID, 'repeatable_fields', true);
$pviews  = get_post_meta($post->ID, 'dt_views_count', true);
$tviews  = ($pviews) ? sprintf( __d('%s Views'), $pviews) : __d('0 Views');
//  Image
$thumb_id   = get_post_thumbnail_id();
$thumb_url  = wp_get_attachment_image_src($thumb_id,'dt_poster_a', true);
$poster_url = ($thumb_id) ? doo_isset($thumb_url,0) : dt_image('dt_poster', $post->ID, 'w185', true, true);
$dynamicbg  = esc_url(rand_images(doo_isset($postmeta,'imagenes'),'original',true,true));


// Options
$player_ads = get_option('dt_vplayer_ads');
$player_wht = get_option('dt_vplayer_width','regular');

// Dynamic Background
if(get_option('dt_dynamic_bg') == 'true') { ?>
<style>
    #dt_contenedor {
        background-image: url(<?php echo $dynamicbg; ?>);
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: cover;
        background-position: 50% 0%;
    }
</style>
<?php }  if($player_wht == 'bigger') { ?>
    <div class="dooplay_player">
        <div id="playcontainer" class="play bigger">
            <?php if($player_ads) echo "<div class='asgdc'>".stripslashes($player_ads)."</div>"; ?>
            <div id="dooplay_player_response"></div>
        </div>
    </div>
<?php } ?>
<!-- Start Single -->
<div id="single" class="dtsingle">

    <!-- Edit link response Ajax -->
    <div id="edit_link"></div>

    <!-- Start Post -->
    <?php if(have_posts()) :while (have_posts()) : the_post(); doo_set_views($post->ID); ?>
    <div class="content">

        <!-- Movie Player Options -->
        <?php if($player OR $trailer){ ?>
        <div class="dooplay_player">
            <?php if($player_wht == 'regular'){ ?>
            <div id="playcontainer" class="play">
                <?php if($player_ads) echo "<div class='asgdc'>".stripslashes($player_ads)."</div>"; ?>
                <div id="dooplay_player_response"></div>
            </div>
            <?php } ?>
            <h2><?php _d('Video Sources'); ?> <span id="playernotice" data-text="<?php echo $tviews; ?>"><?php echo $tviews; ?></span></h2>
            <div id="playeroptions" class="<?php echo (!wp_is_mobile()) ? 'options scrolling' : 'options'; ?>">
                <ul>
                    <?php if($trailer){ ?>
                    <li id="player-option-trailer" class="dooplay_player_option jump on" data-post="<?=$post->ID;?>" data-nume="trailer">
                        <i class="icon-play3"></i>
                        <span class="title"><?php _d('Watch trailer'); ?></span>
                        <span class="server">youtube.com</span>
                        <span class="flag"><i class="yt icon-youtube2"></i></span>
                        <span class="loader"></span>
                    </li>
                <?php } $num = 1; if($player){ foreach($player as $play){ ?>
                    <li id="player-option-<?=$num;?>" class="dooplay_player_option <?php if(!$trailer && $num == 1) echo 'jump on'; ?>" data-post="<?=$post->ID;?>" data-nume="<?=$num;?>">
                        <i class="icon-play3"></i>
                        <span class="title"><?=$play['name'];?></span>
                        <span class="server"><?php echo get_servername($play['url'], $play['select']);?></span>
                        <?php if(doo_isset($play,'idioma')) { echo "<span class='flag'><img src='".DOO_URI."/assets/img/flags/{$play['idioma']}.png'></span>"; } ?>
                        <span class="loader"></span>
                    </li>
                    <?php $num++; } } ?>
                </ul>
            </div>
        </div>
        <?php } ?>


        <!-- Head movie Info -->
        <div class="sheader">
        	<div class="poster">
        		<img src="<?php echo $poster_url; ?>" alt="<?php the_title(); ?>">
        	</div>
        	<div class="data">
        		<h1><?php the_title(); ?></h1>
        		<div class="extra">
        		<?php if($d = doo_isset($postmeta,'tagline')) { echo '<span class="tagline">', $d, '</span>'; } ?>
        		<?php if($d = doo_isset($postmeta,'release_date')) { echo '<span class="date">', doo_date_compose($d), '</span>'; } ?>
        		<?php if($d = doo_isset($postmeta,'Country')) {   echo '<span class="country">', $d, '</span>';  } ?>
        		<?php if($d = doo_isset($postmeta,'runtime')) { echo '<span class="runtime">', $d, ' ', __d('Min.'), '</span>'; }; ?>
        		<?php if($d = doo_isset($postmeta,'Rated')) { echo '<span class="C'. $d .' rated">', $d, '</span>'; } ?>
        		</div>
        		<?php echo do_shortcode('[starstruck_shortcode]'); ?>
        		<div class="sgeneros">
        		<?php echo get_the_term_list($post->ID, 'genres', '', '', ''); ?>
        		</div>
        	</div>
        </div>



        <!-- Movie Tab single -->
        <div class="single_tabs">
            <?php if(is_user_logged_in() OR get_option('dt_register_user') == 'true'){ ?>
        	<div class="user_control">
        		<?php dt_list_button($post->ID); dt_views_button($post->ID); ?>
        	</div>
            <?php } ?>
        	<ul id="section" class="smenu idTabs">
            	<li><a href="#info"><?php _d('Info'); ?></a></li>
            	<li><a href="#linksx"><?php _d('Links'); ?></a></li>
                <li><a href="#cast"><?php _d('Cast'); ?></a></li>
                <li><a href="#report"><?php _d('Report'); ?></a></li>
        	</ul>
        </div>




        <div id="report" class="sbox">
            <?php get_template_part('inc/parts/single/report-video'); ?>
        </div>


        <!-- Movie more info -->
        <div id="info" class="sbox">
            <h2><?php _d('Synopsis'); ?></h2>
            <div itemprop="description" class="wp-content">
                <?php the_content(); ?>
                <?php if($images = doo_isset($postmeta, 'imagenes')) { ?>
                <div id="dt_galery" class="galeria">
                	<?php dt_get_images("w300", $images); ?>
                </div>
                <?php } ?>
                <?php if(get_option('ads_ss_1') =="true") { if($ads = get_option('ads_spot_single')) { echo '<div class="module_single_ads">'. stripslashes($ads). '</div>'; } } ?>
            </div>
            <?php if($d = doo_isset($postmeta, 'original_title')) { ?>
            <div class="custom_fields">
                <b class="variante"><?php _d('Original title'); ?></b>
                <span class="valor"><?php echo $d; ?></span>
            </div>
            <?php } if($d = doo_isset($postmeta, 'imdbRating')) { ?>
            <div class="custom_fields">
        	    <b class="variante"><?php _d('IMDb Rating'); ?></b>
        	    <span class="valor">
        		    <b id="repimdb"><?php echo '<strong>', $d, '</strong> ', doo_isset($postmeta, 'imdbVotes'), ' ', __d('votes'); ?></b>
        	        <?php if(current_user_can('administrator')) { ?><a data-id="<?php echo $post->ID; ?>" data-imdb="<?php echo doo_isset($postmeta, 'ids'); ?>" id="update_imdb_rating"><?php _d('Update Rating'); ?></a><?php } ?>
        	    </span>
            </div>
            <?php } if($d = doo_isset($postmeta, 'vote_average')) { ?>
            <div class="custom_fields">
                <b class="variante"><?php _d('TMDb Rating'); ?></b>
                <span class="valor"><?php echo '<strong>', $d, '</strong> ', doo_isset($postmeta, 'vote_count'), ' ', __d('votes'); ?></span>
            </div>
            <?php } ?>
        </div>


        <!-- Movie Cast -->
        <div id="cast" class="sbox fixidtab">
            <h2><?php _d('Director'); ?></h2>
            <div class="persons">
            	<?php dt_director(doo_isset($postmeta,'dt_dir'), "img", true); ?>
            </div>
            <h2><?php _d('Cast'); ?></h2>
            <div class="persons">
            	<?php dt_cast_2(doo_isset($postmeta,'dt_cast'), "img", true); ?>
            </div>
        </div>


        <!-- Movie Links -->
        <?php if(DOO_THEME_DOWNLOAD_MOD) get_template_part('inc/parts/single/links'); ?>


        <!-- Movie Social Links -->
        <?php links_social_single($post->ID); ?>


        <!-- Movie Related content -->
        <?php if(DOO_THEME_RELATED) get_template_part('inc/parts/single/relacionados'); ?>


        <!-- Movie comments -->
        <?php get_template_part('inc/parts/comments'); ?>


        <!-- Movie breadcrumb -->
        <?php doo_breadcrumb( $post->ID, 'movies', __d('Movies'), 'breadcrumb_bottom' ); ?>


    </div>
    <!-- End Post-->
    <?php endwhile; endif; ?>


    <!-- Movie Sidebar -->
    <div class="sidebar scrolling">
    	<?php dynamic_sidebar('sidebar-movies'); ?>
    </div>
    <!-- End Sidebar -->


</div>
<!-- End Single -->
