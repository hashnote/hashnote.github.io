<?php
/*
* -------------------------------------------------------------------------------------
* @author: Doothemes
* @author URI: https://doothemes.com/
* @aopyright: (c) 2018 Doothemes. All rights reserved
* -------------------------------------------------------------------------------------
*
* @since 2.1.5
*
*/

if(get_option('dt_activate_post_links') == 'true') {
	echo '<div class="box_links">';
	get_template_part('inc/parts/single/listas/links');
	echo '</div>';
}
