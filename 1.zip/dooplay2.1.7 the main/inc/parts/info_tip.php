<?php
/*
* -------------------------------------------------------------------------------------
* @author: Doothemes
* @author URI: https://doothemes.com/
* @aopyright: (c) 2018 Doothemes. All rights reserved
* -------------------------------------------------------------------------------------
*
* @since 2.1.3
*
*/


$genres = get_the_term_list($post->ID, 'genres', '<div class="genres"><div class="mta">', '', '</div></div>');
?>
<div class="animation-1 dtinfo">
	<div class="title">
		<h4><?php the_title(); ?></h4>
	</div>
	<div class="metadata">
		<?php echo ($imdb = dt_get_meta('imdbRating')) ? '<span class="imdb">IMDb: '.$imdb.'</span>' : ''; ?>
		<?php echo ($year = dt_get_meta('release_date')) ? '<span>'. date('Y', strtotime($year)) .'</span>' : ''; ?>
        <?php echo ($year = dt_get_meta('first_air_date')) ? '<span>'. date('Y', strtotime($year)) .'</span>' : ''; ?>
		<?php echo ($time = dt_get_meta('runtime')) ? '<span>'.$time.' '. __d('min') .'</span>' : ''; ?>
		<?php echo ($views = dt_get_meta('dt_views_count')) ? '<span>'.$views.' '. __d('views') .'</span>' : ''; ?>
	</div>
	<div class="texto"><?php dt_content_alt('150'); ?></div>
	<?php echo $genres; ?>
</div>
