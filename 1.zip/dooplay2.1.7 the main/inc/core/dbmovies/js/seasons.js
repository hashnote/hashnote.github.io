jQuery(document).ready(function($) {

	// Function generate data on click
	$('#generate_data_api').click(function() {

		var ids		= $('#ids').get(0).value
		var cont	= $('#temporada').get(0).value
		var dbm		= DTapi.dbm + 'app/'
		var dbmkey  = DTapi.dbmkey
		var tmdkey  = '&api_key=' + DTapi.tmdkey
		var append  = '?append_to_response=images'
		var lang	= '&language='+ DTapi.lang +'&include_image_language='+ DTapi.lang +',null'
		var tmd		= DTapi.tmd
		var pda		= DTapi.pda

		$('#api_table').addClass( "hidden_api" )
		$('#loading_api').html('<p><span class="spinner"></span> '+ DTapi.loading +'</p>')

		if( pda == 1 ) {
			// GET Api

							// GET TMDb
							$.getJSON( tmd + ids + '/season/' + cont + append + lang + tmdkey , function(tmddata) {

								$('#loading_api').html('')
								$('#api_table').removeClass( "hidden_api" )

								var valPlo = "";
								var valImg = "";
								var valBac = "";
								var valTit = "";
								var valupimg = "";
								$.each(tmddata, function(key, val) {
									$('input[name=' + key + ']').val(val);
									$('#message').remove();
									$("#verificador").show();
									if (key == "overview") {
										if (typeof tinymce != "undefined") {
											var editor = tinymce.get('content');
											if (editor && editor instanceof tinymce.Editor) {
												editor.setContent(val);
												editor.save({
													no_events: true
												});
											} else {
												$('textarea#content').val(val);
											}
										}
									}
									if (key == "name") {
										valTit += "" + val + "";
									}
									$.getJSON( tmd + ids + '?language=' + DTapi.lang + tmdkey , function(tmddata) {
										$.each(tmddata, function(key, item) {
											if (key == "name") {
												$('#serie').val(item);
												$('label#title-prompt-text').addClass('screen-reader-text');
												$('input[name=post_title]').val(item + ": " + DTapi.slug +" "+ cont);
											}
										});
									});
									$.getJSON( tmd + ids + '/season/' + cont + '?language=' + DTapi.lang + tmdkey, function(tmddata) {
										$.each(tmddata, function(key, item) {
											if (key == "poster_path") {
												$('#dt_poster').val(item);
												if ( DTapi.upload == 1 ) {
													if (DTapi.post != 'edit') {
														$('#url_image_upload').val("https://image.tmdb.org/t/p/w500"+item);
														$('#postimagediv p').html("<ul><li><img class='dt_poster_preview' src='https://image.tmdb.org/t/p/w500"+ item +"'/> </li></ul>");
													}
												}
											}
										});
									});
								});
							});

		}
	});
	if( DTapi.pda != 1 ) $('#generate_data_api').hide();
});
