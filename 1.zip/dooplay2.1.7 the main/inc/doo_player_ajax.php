<?php
/*
* ----------------------------------------------------
* @author: Doothemes
* @author URI: https://doothemes.com/
* @copyright: (c) 2018 Doothemes. All rights reserved
* ----------------------------------------------------
*
* @since 2.1.6
*/

# Get player by ajax
if(!function_exists('doo_player_ajax' )){
    function doo_player_ajax(){
        // POST Data
        $post_id = doo_isset($_POST,'post');
        $play_nm = doo_isset($_POST,'nume');
        // Verify data
        if($post_id && $play_nm){
            // Get post meta
            $postmeta = get_post_meta($post_id, 'repeatable_fields', true);
            // compose data
            $pag = get_option('dt_jwplayer_page');
            $url = doo_player_isset($postmeta, ($play_nm-1),'url');
            $typ = ($play_nm == 'trailer') ? 'trailer' : doo_player_isset($postmeta, ($play_nm-1),'select');
            // verify data
            if($typ){
                switch($typ) {
                    case 'iframe':
                        $code = "<if"."rame class='metaframe rptss' src='{$url}' frameborder='0' scrolling='no' allow='autoplay; encrypted-media' allowfullscreen></ifr"."ame>";
                        break;

                    case 'mp4':
                    case 'gdrive':
                        $code = "<if"."rame class='metaframe rptss' src='{$pag}?source=".urlencode($url)."&id={$post_id}&type={$typ}' frameborder='0' scrolling='no' allow='autoplay; encrypted-media' allowfullscreen></ifr"."ame>";
                        break;

                    case 'trailer':
                        $code = mostrar_trailer_iframe(get_post_meta($post_id, "youtube_id", $single = true), 1);
                        break;

                    case 'dtshcode':
                        $code = do_shortcode($url);
                        break;
                }
                // Return Player
                echo apply_filters('doo_player_ajax', $code, $url, $typ);
            }
        }
        // End Action
        wp_die();
    }
    add_action('wp_ajax_doo_player_ajax', 'doo_player_ajax');
	add_action('wp_ajax_nopriv_doo_player_ajax', 'doo_player_ajax');
}


# Is set Player data
function doo_player_isset($data = array(), $n, $k){
    return (isset($data[$n][$k])) ? $data[$n][$k] : false;
}
