== DooPlay ==
Contributors: Doothemes team
Requires at least: WordPress 4.8+
Tested up to: WordPress 4.9.8
Version: 2.1.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Copyright ==

DooPlay WordPress Theme, Copyright 2016-2018 Doothemes.com & themes.pe

== Change Log ==


= 2.1.7 =
* Released: August 15, 2018

https://doothemes.com/items/dooplay/?view=changelog#version_2.1.7

= 2.1.6 =
* Released: August 14, 2018

https://doothemes.com/items/dooplay/?view=changelog#version_2.1.6

= 2.1.5 =
* Released: August 12, 2018

https://doothemes.com/items/dooplay/?view=changelog#version_2.1.5

= 2.1.4 =
* Released: July 31, 2018

https://doothemes.com/items/dooplay/?view=changelog#version_2.1.4

= 2.1.3.9 =
* Released: Novenber 22, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.1.3.9

= 2.1.3.8 =
* Released: October 23, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.1.3.8

= 2.1.3.5 =
* Released: October 23, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.1.3.5

= 2.1.3 =
* Released: October 20, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.1.3

= 2.1 =
* Released: July 11, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.1

= 2.0.7 =
* Released: June 14, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.0.7

= 2.0.6 =
* Released: June 10, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.0.6

= 2.0.5 =
* Released: June 8, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.0.5

= 2.0.4 =
* Released: May 28, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.0.4

= 2.0.3 =
* Released: May 20, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.0.3

= 2.0.2 =
* Released: April 15, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.0.2

= 2.0.1 =
* Released: April 14, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.0.1

= 2.0 =
* Released: April 7, 2017

https://doothemes.com/items/dooplay/?view=changelog#version_2.0.0
